package com.parkingwang.vehiclekeyboard.support;

public interface MessageHandler {

    void onMessageError(int message);

    void onMessageTip(int message);
}